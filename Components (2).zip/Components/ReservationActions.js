export const makeReservation = (data) => {
    return {
        type: 'MAKE_RESERVATION',
        payload: data
    };
};
