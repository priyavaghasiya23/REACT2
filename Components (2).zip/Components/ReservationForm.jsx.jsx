import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { makeReservation } from '../actions/reservationActions';

const ReservationForm = () => {
    const [name, setName] = useState('');
    const dispatch = useDispatch();

    const handleSubmit = (e) => {
        e.preventDefault();
        dispatch(makeReservation({ name }));
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" placeholder="Enter Name" value={name} onChange={(e) => setName(e.target.value)} />
            <button type="submit">Reserve</button>
        </form>
    );
};

export default ReservationForm;
