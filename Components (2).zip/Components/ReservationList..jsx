import React from 'react';

const ReservationList = () => {
    return (
        <div>
            <h2>Reservations</h2>
            <ul>
                <li>John Doe</li>
                <li>Jane Smith</li>
            </ul>
        </div>
    );
};

export default ReservationList;
