export const getRooms = () => {
    return {
        type: 'GET_ROOMS'
    };
};
