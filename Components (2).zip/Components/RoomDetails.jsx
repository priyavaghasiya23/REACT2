import React from 'react';

const RoomDetails = () => {
    return <div>Room Details Component</div>;
};

export default RoomDetails;
