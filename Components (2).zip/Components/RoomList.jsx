import React from 'react';
import RoomDetails from './RoomDetails';

const RoomList = () => {
    return (
        <div>
            <h2>Room List</h2>
            <RoomDetails />
        </div>
    );
};

export default RoomList;
