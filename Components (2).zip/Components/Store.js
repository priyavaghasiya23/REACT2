import { createStore, combineReducers } from 'redux';

// Dummy reducers (Replace with actual ones)
const reservationReducer = (state = [], action) => {
    switch (action.type) {
        case 'MAKE_RESERVATION':
            return [...state, action.payload];
        default:
            return state;
    }
};

const roomReducer = (state = [], action) => {
    switch (action.type) {
        case 'GET_ROOMS':
            return state;
        default:
            return state;
    }
};

// Root reducer
const rootReducer = combineReducers({
    reservations: reservationReducer,
    rooms: roomReducer
});

// Create store
const store = createStore(rootReducer);

export default store;
