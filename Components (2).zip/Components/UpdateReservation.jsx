const updateReservation = async (reservationId, newDetails) => {
    const response = await fetch(`/reservations/${reservationId}`, {
        method: 'PUT',
        body: JSON.stringify(newDetails),
        headers: { 'Content-Type': 'application/json' },
    });
    const updatedReservation = await response.json();
    dispatch({ type: 'UPDATE_RESERVATION', payload: updatedReservation });
};

const cancelReservation = async (reservationId) => {
    await fetch(`/reservations/${reservationId}`, {
        method: 'DELETE',
    });
    dispatch({ type: 'DELETE_RESERVATION', payload: reservationId });
};
